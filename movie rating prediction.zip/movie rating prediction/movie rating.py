import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Load the dataset
data = pd.read_csv('IMDb Movies India.csv', encoding='ISO-8859-1')

# Data Cleaning and Preprocessing

# Convert 'Votes' to numeric by removing commas and handling non-numeric values
data['Votes'] = pd.to_numeric(data['Votes'].str.replace(',', ''), errors='coerce')

# Convert 'Duration' to numeric by removing ' min' and converting to minutes
data['Duration'] = data['Duration'].str.replace(' min', '').astype(float)

# Ensure 'Year' is treated as string, then extract the year using regex
data['Year'] = data['Year'].astype(str).str.extract(r'(\d{4})').astype(float)

# Drop rows where 'Rating' is missing since it's our target variable
data = data.dropna(subset=['Rating'])

# Fill missing values in 'Votes', 'Duration', and 'Year' with the median
data['Votes'] = data['Votes'].fillna(data['Votes'].median())
data['Duration'] = data['Duration'].fillna(data['Duration'].median())
data['Year'] = data['Year'].fillna(data['Year'].median())

# Features and target
X = data[['Year', 'Duration', 'Votes']]
y = data['Rating']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict ratings
y_pred = model.predict(X_test)

# Calculate the Mean Squared Error
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')

# Predicting for a new sample
new_sample = pd.DataFrame({
    'Year': [2022],         # Replace with actual values
    'Duration': [120],      # Replace with actual values
    'Votes': [10000]        # Replace with actual values
})
predicted_rating = model.predict(new_sample)
print(f'Predicted Rating: {predicted_rating[0]}')
