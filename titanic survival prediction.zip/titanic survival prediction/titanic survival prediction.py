import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load the dataset
data = pd.read_csv('Titanic-Dataset.csv')

# Data Preprocessing

# Fill missing values
data['Age'].fillna(data['Age'].median(), inplace=True)
data['Embarked'].fillna(data['Embarked'].mode()[0], inplace=True)

# Convert categorical columns to numeric
data['Sex'] = data['Sex'].map({'male': 0, 'female': 1})
data['Embarked'] = data['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})

# Drop columns that won't be used
data.drop(columns=['Cabin', 'Name', 'Ticket', 'PassengerId'], inplace=True)

# Define features and target
X = data[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']]
y = data['Survived']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the model
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy}')
print('Classification Report:')
print(classification_report(y_test, y_pred))
print('Confusion Matrix:')
print(confusion_matrix(y_test, y_pred))

# Predicting survival for a new sample
new_sample = pd.DataFrame({
    'Pclass': [3],      # Replace with actual values
    'Sex': [0],         # 0 for male, 1 for female
    'Age': [25],        # Age of the passenger
    'SibSp': [0],       # Number of siblings/spouses aboard
    'Parch': [0],       # Number of parents/children aboard
    'Fare': [7.25],     # Passenger fare
    'Embarked': [0]     # 0 for S, 1 for C, 2 for Q
})
predicted_survival = model.predict(new_sample)
print(f'Predicted Survival: {"Survived" if predicted_survival[0] == 1 else "Did not survive"}')
