import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import pandas as pd
import matplotlib.pyplot as plt
import warnings
import seaborn as sns

warnings.filterwarnings("ignore", category=UserWarning)

# Load the dataset - update the path if needed
data = pd.read_csv("IRIS.csv")

# Display the first 5 rows of the dataset
print(data.head(5))

# Check for any missing values
print(data.isnull().sum())

# Display information about the dataset
print(data.info())

# Plot heatmap for feature correlations
plt.figure(figsize=(10,8))
sns.heatmap(data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']].corr(), vmin=-1.0, vmax=1.0, annot=True, linewidths=2)
plt.show()

# Features and target variable
x = data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
y = data['species']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# Initialize the KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=3)

# Train the model
knn.fit(X_train, y_train)

# Make predictions on the test set
y_pred = knn.predict(X_test)

# Calculate the accuracy
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Predict the species of a new sample
new_data = np.array([[5.7, 2.8, 4.1, 1.3]])
prediction = knn.predict(new_data)
print("Predicted species:", prediction)

